#ifndef CONFIG_H
#define CONFIG_H

using namespace std;

class config {
public:
    int priority_N = 2;
};

#endif